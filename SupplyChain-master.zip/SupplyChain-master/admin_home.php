<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
    <title>CRUD DATABASE</title>
</head>

<body>
    <div class="head">
        <h1>CRUD DATABASE</h1>
    </div>
    <div class="img"></div>
    <div class="box box-1">
        <a href="CRUD/cust_func/cust_add.php" target="blank">
            <div class="btn">
                <span>CUSTOMER</span>
            </div>
        </a>
    </div>

  
    <div class="box box-2">
        <a href="CRUD/supp_func/suppadd.php" target="blank">
            <div class="btn btn-two">
              <span>supplier</span>
            </div>
        </a>
    </div>    
     <div class="box box-3">
        <a   href="CRUD/product_func/proadd.php" target="blank">
            <div class="btn btn-four">
                <span>products</span>
            </div>
            <a>
    </div>
</body>
</body>

</html>
